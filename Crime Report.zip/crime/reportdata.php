<?php

$db = mysqli_connect('localhost','root','','crime')
 or die('Error connecting to MySQL server.');
 
 $name= $_POST['name'];
 $phone= $_POST['phone'];
 $email= $_POST['email'];
 $address= $_POST['address'];
 $Crimetype= $_POST['Crimetype'];
 $tname= $_POST['tname'];
 $Iname= $_POST['Iname'];
 $Discription= $_POST['Discription'];
 $cname= $_POST['cname'];
 $Height= $_POST['Height'];
 $sinfo= $_POST['sinfo'];


 
 $sql= "insert into report(name,phone,email,address,Crimetype,tname,Iname,Discription,cname,Height,sinfo) values('$name', '$phone','$email','$address','$Crimetype','$tname','$Iname','$Discription','$cname','$Height','$sinfo')";
 	if(mysqli_query($db,$sql)){
		 echo "Successfully inserted to the table";
		}
	 else{
		 echo "not inserted into the table";
	 }
 	}

?>