<!DOCTYPE html>
<html>
<head>
  <title>SignUp Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="wrap">
     <form action="reginsert.php" method="post">
         <h2> SIGNUP FORM</h2><br>
          <input type="text" name="name" placeholder="Your Name" required>
          <input type="email" name="email" placeholder="Your E-mail" required>
          <input type="tel" name="mobile" placeholder="Mobile Number" required>
          <input type="Password" name="password_1" placeholder="Password" required>
          <input type="Password" name="password_2" placeholder="Confirm Password" required>
          <br>
          <br>
          <span style="font-size: 18px;"> Date of Birth</span>
          <br>
          <input type="date" name="bday" required>
          <br>
   
          <input type="radio" name="gender" value="male" checked  > Male
           <input type="radio" name="gender" value="female"> Female
           <br>
          <input type="checkbox"> I agree to the Terms of use <br>
          <input type="submit" value="REGISTER">

  </form>
  
</body>
</html>