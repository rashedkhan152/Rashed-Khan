<?php

$db = mysqli_connect('localhost','root','','crime')
 or die('Error connecting to MySQL server.');
 
 $name= $_POST['name'];
 $mobile= $_POST['mobile'];
 $email= $_POST['email'];
 $password_1=md5($_POST['password_1']);
 $password_2= md5($_POST['password_2']);
 $bday= $_POST['bday'];


 
 $sql= "insert into info(name,mobile,email,password_1,password_2,bday) values('$name', '$mobile','$email','$password_1','password_2','$bday')";
 	 if($password_1 == $password_2){
 	if(mysqli_query($db,$sql)){
		 
		 header("refresh:1; url=loginform.php");
		}
	 else{
		 echo "not inserted into the table";
		  header("refresh:2; url=loginform.php");
	 }
 	}
 	else{
	 echo "don't match password and confirm_password";
	  header("refresh:2; url=registration.php");
}

?>