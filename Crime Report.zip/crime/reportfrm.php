<!DOCTYPE html>
<html>
<head>
	<title>Report form</title>
	<style type="text/css">
		body{
			background-color:#b3b3ff;
		}
	</style>

</head>
<body>
<form action="reportdata" method="post">
	<p> Please note that this form of report only applies to: larceny, vandalism, annoying/harassing phone calls, computer harassment, drugs, or assaults. All other crimes should be reported directly to the Virginia Tech Police Department at 540-231-6411, or by dialing 911. Reports may also be filed in person at the station. If the incident occurred off campus, please contact the appropriate local law enforcement agency. This is a formal report. You are required to enter your name and contact information. Please provide as much detail as possible.</p>
	 <p style="font-weight: bold;">Contact Information</p>
	*Name:
	<input type="text" name="name"><br>
	*University Affiliation:
	<select name="UniversityAffiliation">
   		 <option value="Student">Student</option>
   		 <option value="Employee">Employee</option>
   		 <option value="Non-Affiliated/Other">Non-Affiliated/Other</option>
	</select><br>
	*Email:
	<input type="Email" name="Email" required><br>
	*Phone:
	<input type="tel" name="Phone" required><br>
	*Local Address:
	<input type="text" name="address"><br>

	<p style="font-weight: bold;">Report Data</p><br>

	*Report Type:
	<select name="CrimeType">
   		 <option value="Larceny/Theft">Larceny/Theft</option>
   		 <option value="Vandalism">Vandalism</option>
   		 <option value="Assault">Assault</option>
   		 <option value="Harassing Phone Calls">Harassing Phone Calls</option>
   		 <option value="Computer Harassment">Computer Harassment</option>
  		 <option value="Narcotics/Drugs">Narcotics/Drugs</option>
	</select><br>
	* Time of Incident: 
	<input type="text" name="tname" required><br>
	
* Incident Location:
	<input type="text" name="Iname"><br>
	*Incident Discription:
	<textarea name="Discription"></textarea><br>
	 <p style="font-weight: bold;">Suspect Information (as known)</p>
	 *Name:
	 <input type="text" name="cname"><br>
	 *Height:
	 <select name="Height">
    <option value="48 inches - 4' 0&quot;">48 inches - 4' 0"</option>
    <option value="49 inches - 4' 1&quot;">49 inches - 4' 1"</option>
    <option value="50 inches - 4' 2&quot;">50 inches - 4' 2"</option>
    <option value="51 inches - 4' 3&quot;">51 inches - 4' 3"</option>
    <option value="52 inches - 4' 4&quot;">52 inches - 4' 4"</option>
    <option value="53 inches - 4' 5&quot;">53 inches - 4' 5"</option>
    <option value="54 inches - 4' 6&quot;">54 inches - 4' 6"</option>
    <option value="55 inches - 4' 7&quot;">55 inches - 4' 7"</option>
    <option value="56 inches - 4' 8&quot;">56 inches - 4' 8"</option>
    <option value="57 inches - 4' 9&quot;">57 inches - 4' 9"</option>
    <option value="58 inches - 4' 10&quot;">58 inches - 4' 10"</option>
    <option value="59 inches - 4' 11&quot;">59 inches - 4' 11"</option>
    <option value="60 inches - 5' 0&quot;">60 inches - 5' 0"</option>
    <option value="61 inches - 5' 1&quot;">61 inches - 5' 1"</option>
    <option value="62 inches - 5' 2&quot;">62 inches - 5' 2"</option>
    <option value="63 inches - 5' 3&quot;">63 inches - 5' 3"</option>
    <option value="64 inches - 5' 4&quot;">64 inches - 5' 4"</option>
    <option value="65 inches - 5' 5&quot;">65 inches - 5' 5"</option>
    <option value="66 inches - 5' 6&quot;">66 inches - 5' 6"</option>
    <option value="67 inches - 5' 7&quot;">67 inches - 5' 7"</option>
    <option value="68 inches - 5' 8&quot;">68 inches - 5' 8"</option>
    <option value="69 inches - 5' 9&quot;">69 inches - 5' 9"</option>
    <option value="70 inches - 5' 10&quot;">70 inches - 5' 10"</option>
    <option value="71 inches - 5' 11&quot;">71 inches - 5' 11"</option>
    <option value="72 inches - 6' 0&quot;">72 inches - 6' 0"</option>
    <option value="73 inches - 6' 1&quot;">73 inches - 6' 1"</option>
    <option value="74 inches - 6' 2&quot;">74 inches - 6' 2"</option>
    <option value="75 inches - 6' 3&quot;">75 inches - 6' 3"</option>
    <option value="76 inches - 6' 4&quot;">76 inches - 6' 4"</option>
    <option value="77 inches - 6' 5&quot;">77 inches - 6' 5"</option>
</select><br>
Additional Suspect Information <em>(examples include: vehicle, clothing, scars, tattoos, etc.):
	<textarea name="sinfo"></textarea><br>
	<input type="submit" name="submit">
</form>
</body>
</html>