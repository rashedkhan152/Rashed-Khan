<!DOCTYPE html>
<html>
<head>
  <title>SignUp Form</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="wrap">
     <form action="login.php" method="post">
         <h2> SIGNIN FORM</h2>
      
          <input type="email" name="email" placeholder="Your E-mail" required>
         
          <input type="Password" name="password_1" placeholder="Password" required>
          <br>
          <br>
          <input type="submit" value="LOGIN">

  </form>
  
</body>
</html>