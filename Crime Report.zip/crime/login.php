<?php
	$email	=($_POST["email"]);
	$password_1 	=md5($_POST["password_1"]);


	$con=mysqli_connect("localhost","root","") or die("Error connecting to MySQL Server");

	mysqli_select_db($con,"crime");
	
	$sql = mysqli_query($con, "SELECT * FROM info WHERE email = '".$email."' and password_1 = '".$password_1."'");
	$row = mysqli_fetch_array($sql);
	//$row = mysqli_num_rows($con,$sql);
	if(empty($_POST["email"] && $_POST["password_1"])){
		echo "Enter the username and password";
	}
		//if(!$row){		
		else{
			 if ($row['email']==$email && $row['password_1']==$password_1) {
				 
				 echo "Incorrect Username or Password";
				
				} else {
					
				 header("refresh:2; url=reportfrm.php");
				
			}
		}

	
?>